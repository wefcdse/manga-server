use std::{
    collections::HashMap,
    io::{BufRead, Write},
};

use async_zip::{ZipFile, ZipFileBuilder};

#[test]
fn generate_id_mapping() {
    let p = r"H:\g\Books\manga\mapping";
    let mut c = 0;
    let w = walkdir::WalkDir::new(p);
    let mut h: HashMap<u64, String> = HashMap::new();
    for i in w {
        let i = match i {
            Ok(i) => i,
            Err(_) => continue,
        };
        if i.file_type().is_file() {
            let name = i.file_name().to_str().unwrap().to_owned();
            let id: u64 = name.split(" ").next().unwrap().parse().unwrap();
            let name = {
                let mut n = name.split(" ");
                n.next();
                n.next()
            }
            .unwrap()
            .split(".")
            .next()
            .unwrap()
            .to_owned();
            if h.contains_key(&id) {
                panic!()
            } else {
                h.insert(id, name);
            }
            c += 1;
        };
    }
    use std::fs;
    let mut f = fs::OpenOptions::new()
        .write(true)
        .truncate(true)
        .create_new(true)
        .open("mapping.txt")
        .unwrap();
    let mut a: Vec<u64> = h.iter().map(|(k, _)| *k).collect();
    a.sort();
    let b = a
        .iter()
        .map(|id| (*id, h.get(id).unwrap().to_owned()))
        .collect::<Vec<_>>();

    for (k, v) in &b {
        write!(f, "{}==>{}\n", k, v).unwrap();
        println!("{:5} {:5}", k, v);
    }
    println!("{}", c);
    println!("{}", h.len());
    println!("{:?}", b);
}

fn read_id_mapping(path: &str) {
    use std::fs;
    let mut f = fs::OpenOptions::new().read(true).open(path).unwrap();

    use std::io::BufReader;
    let mut f = BufReader::new(f);
    loop {
        let mut s = String::new();
        let line = f.read_line(&mut s).unwrap();
        if line == 0 {
            break;
        }
        let mut s = s.split("==>");
        let id = s.next().unwrap().parse::<u64>().unwrap();
        let name = s
            .next()
            .unwrap()
            .chars()
            .filter(|c| !c.is_whitespace())
            .collect::<String>()
            .to_owned();
        println!("{}:{}", id, name);
    }
}
#[test]
fn t() {
    read_id_mapping("mapping.txt");
}
#[test]
fn t_unzip() {
    let a = async {
        use async_zip::tokio::read::seek::ZipFileReader;
        use tokio::{fs::File, io::AsyncReadExt};
        let mut file = File::open("./test.zip").await.unwrap();

        let mut zip = ZipFileReader::with_tokio(&mut file).await.unwrap();

        let mut string = String::new();

        let f = zip.file();
        for e in f.entries() {
            println!("{}", e.entry().filename().as_str().unwrap());
        }

        let mut reader = zip.reader_with_entry(1).await.unwrap();
        let l = reader.read_to_string_checked(&mut string).await.unwrap();

        //println!("{}", string);
    };
    let rt = tokio::runtime::Builder::new_current_thread()
        .build()
        .unwrap();
    rt.block_on(a);
}
