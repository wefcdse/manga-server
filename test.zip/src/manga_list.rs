use std::{collections::HashMap, sync::Mutex};

use serde::Serialize;

#[derive(Debug, Serialize, PartialEq, Eq)]
pub struct MangaInfo {
    pub name: String,
    pub pic: String,
    pub id: String,
}

static MANGA_LIST: Mutex<Option<(String, HashMap<String, MangaInfo>)>> = Mutex::new(None);
pub fn init(root_path: &str) {
    let mut l = MANGA_LIST.lock().unwrap();
    if let None = *l {
        *l = Some((root_path.to_owned(), HashMap::new()));
    }
}

#[test]
fn t() {
    let p = r"H:\g\Books\manga\zips";
    let mut c = 0;
    let w = walkdir::WalkDir::new(p);
    let mut h: HashMap<u64, usize> = HashMap::new();
    for i in w {
        let i = match i {
            Ok(i) => i,
            Err(_) => continue,
        };
        if i.file_type().is_file() {
            let name = i.file_name().to_str().unwrap().to_owned();
            let id: u64 = name.split("_").next().unwrap().parse().unwrap();
            if h.contains_key(&id) {
                *h.get_mut(&id).unwrap() += 1;
            } else {
                h.insert(id, 1);
            }
            c += 1;
        };
    }

    for (k, v) in &h {
        println!("{:5} {:5}", k, v);
    }
    println!("{}", c);
    println!("{}", h.len());
}
