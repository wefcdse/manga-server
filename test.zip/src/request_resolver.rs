use hyper::{Body, Request, Response, Uri};
use std::error::Error;
use std::fmt::Display;

use tokio::fs;

use crate::manga_list::MangaInfo;

#[derive(Debug, Clone)]
struct StringError {
    e: String,
}
impl Display for StringError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Error:{}", self.e)
    }
}
impl Error for StringError {}
impl StringError {
    pub fn new(s: &str) -> Self {
        Self { e: s.to_owned() }
    }
}

pub fn err<T>(s: &str) -> Result<T, Box<dyn Error>> {
    Err(StringError::new(s).into())
}

pub async fn resolve(req: Request<Body>) -> Result<Response<Body>, Box<dyn Error>> {
    let uri = req.uri();
    let path = uri.path().to_owned();
    dbg!(&path);
    let p: Vec<&str> = path.split("/").collect();
    dbg!(&p);
    let first_path = match p.get(1) {
        Some(v) => v.to_owned().to_owned(),
        None => return err("why no 1"),
    };

    let response = match &first_path {
        v if v == "favicon.ico" => {
            let f = fs::read("res/favicon.ico").await?;
            Response::new(Body::from(f))
        }
        v if v == "" => {
            let f = fs::read("res/html/index.html").await?;
            Response::new(Body::from(f))
        }
        v if v == "pic" => {
            let name = p.get(2);
            if let Some(name) = name {
                let f = get_res("pic", name).await?;
                Response::new(Body::from(f))
            } else {
                return err("img not found");
            }
        }

        v if v == "css" => {
            let name = p.get(2);
            if let Some(name) = name {
                let f = get_res("css", name).await?;
                Response::new(Body::from(f))
            } else {
                return err("img not found");
            }
        }

        v if v == "info" => {
            let info = p.get(2);
            if let Some(info) = info {
                let i = get_info(*info, &uri).await?;
                Response::new(Body::from(i))
            } else {
                return err("img not found");
            }
        }

        _ => {
            let f = fs::read("res/html/404.html").await?;

            Response::new(Body::from(f))
        }
    };

    Ok(response)
}

async fn get_res(t: &str, name: &str) -> Result<Vec<u8>, std::io::Error> {
    let f = fs::read(dbg!(&format!("res/{}/{}", t, name))).await?;
    Ok(f)
}

async fn get_info(info: &str, uri: &Uri) -> Result<Vec<u8>, std::io::Error> {
    let out = match info {
        i if i == "all_manga" => {
            let list: Vec<MangaInfo> = (0..100)
                .into_iter()
                .map(|_| MangaInfo {
                    name: "aaa".to_owned(),
                    pic: "pic/1.png".to_owned(),
                    id: "ffdfd".to_owned(),
                })
                .collect();
            serde_json::to_string(&list)?.into_bytes()
        }
        _ => {
            return Ok("".as_bytes().to_owned());
        }
    };

    Ok(out)
}
